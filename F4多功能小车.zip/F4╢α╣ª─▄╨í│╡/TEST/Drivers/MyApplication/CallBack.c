/* Includes ------------------------------------------------------------------*/
#include "MyApplication.h"
#include "CallBack.h"                  // Device header

/* Private define-------------------------------------------------------------*/

/* Private variables----------------------------------------------------------*/


/* Public variables-----------------------------------------------------------*/

/* Private function prototypes------------------------------------------------*/      

extern uint8_t cmd;

/*
	* @name   HAL_TIM_PeriodElapsedCallback
	* @brief  ��ʱ���жϻص�����
	* @param  *htim -> ������ʱ���Ľṹ��ָ��
	* @retval None      
*/
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == htim3.Instance)
	{
		//����֧�����У�ָʾ�Ƽ��1s��˸
		if(++Timer3.usMCU_Run_Timer >= TIMER3_1S)
		{
			Timer3.usMCU_Run_Timer = 0;
			LED.LED_Flip(LED1);
		}
	}
}


/*
	* @name   HAL_UART_IdleCallback
	* @brief  ���ڿ����жϻص�����
	* @param  *htim -> �������ڵĽṹ��ָ��
	* @retval None      
*/
void HAL_UART_IdleCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == huart2.Instance)
	{
		VOICE.Serial_Proc(&UART2);
		HAL_UART_Receive_DMA(&huart2,UART2.pucRec_Buffer,UART2_Rec_LENGTH);
		
		
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART3){
		if(cmd!=53)
		{
			DC_Motor.Start();
		}
		switch(cmd)
		{
			case 49: DC_Motor.Motor_Up(); DC_Motor.Direction = Forward_State; break;
			case 50: DC_Motor.Motor_Down(); DC_Motor.Direction = Reverse_State;break;
			case 51: DC_Motor.Motor_Left(); break;
			case 52: DC_Motor.Motor_Right(); break;
			case 53: DC_Motor.Stop(); break;
			case 54: DC_Motor.Back_status = 1;break;

			default:
				 break;				
		}		
	}
    
    
    //��
    if(huart->Instance == USART_UX)             /* ����Ǵ���1 */
    {
        if((g_usart_rx_sta & 0x8000) == 0)      /* ����δ��� */
        {
            if(g_usart_rx_sta & 0x4000)         /* ���յ���0x0d */
            {
                if(g_rx_buffer[0] != 0x0a) 
                {
                    g_usart_rx_sta = 0;         /* ���մ���,���¿�ʼ */
                }
                else 
                {
                    g_usart_rx_sta |= 0x8000;   /* ��������� */
                }
            }
            else                                /* ��û�յ�0X0D */
            {
                if(g_rx_buffer[0] == 0x0d)
                {
                    g_usart_rx_sta |= 0x4000;
                }
                else
                {
                    g_usart_rx_buf[g_usart_rx_sta & 0X3FFF] = g_rx_buffer[0] ;
                    g_usart_rx_sta++;
                    if(g_usart_rx_sta > (USART_REC_LEN - 1))
                    {
                        g_usart_rx_sta = 0;     /* �������ݴ���,���¿�ʼ���� */
                    }
                }
            }
        }
    }
}

/********************************************************
  End Of File
********************************************************/
