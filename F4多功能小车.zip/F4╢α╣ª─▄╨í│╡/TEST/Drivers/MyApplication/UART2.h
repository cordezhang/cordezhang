#ifndef __UART2_H__
#define __UART2_H__

/* define ------------------------------------------------------------------*/
#include "MyApplication.h"

#define UART2_Send_LENGTH  9
#define UART2_Rec_LENGTH 	 9

/* extern variables-----------------------------------------------------------*/
extern UART_t  UART2;

/* extern function prototypes-------------------------------------------------*/

#endif
/********************************************************
  End Of File
********************************************************/

