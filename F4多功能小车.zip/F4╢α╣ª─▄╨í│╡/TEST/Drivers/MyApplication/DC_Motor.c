/* Includes ------------------------------------------------------------------*/
#include "MyApplication.h"

/* Private define-------------------------------------------------------------*/

/* Private variables----------------------------------------------------------*/

/* Private function prototypes------------------------------------------------*/      
static void Start(void);    //ֱ���������
static void Stop(void);	    //ֱ�����ֹͣ

static void Motor_Up(void); //ǰ��
static void Motor_Down(void); //����
static void Motor_Left(void); //��ת
static void Motor_Right(void); //��ת
static void Speed_Adjust(uint16_t);  //ֱ������ٶȵ���
static void Back_Car(void);
static void Out_Car(void);


#define   IN1  HAL_GPIO_ReadPin(IN1_GPIO_Port,IN1_Pin)	
#define   IN2  HAL_GPIO_ReadPin(IN2_GPIO_Port,IN2_Pin)	
#define   IN3  HAL_GPIO_ReadPin(IN3_GPIO_Port,IN3_Pin)	
	
/* Public variables-----------------------------------------------------------*/

//����ṹ�������
DC_Motor_t DC_Motor = 
{
  Stop_State,
	Reverse_State, 
	Speed_Two,
	0,
	
	Start,
	Stop,
	Motor_Up,
	Motor_Down,
	Motor_Left,
	Motor_Right,
	Speed_Adjust,
	Back_Car,
	Out_Car
};

/*
	* @name   Start
	* @brief  ֱ���������
	* @param  None
	* @retval None      
*/
static void Start(void)
{
	//�������
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_4);
	
	//���µ��״̬
	DC_Motor.Status = Start_State;
}

/*
	* @name   Stop
	* @brief  ֱ�����ֹͣ
	* @param  None
	* @retval None      
*/
static void Stop(void)
{
	//ֹͣ���
	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_4);
	//���µ��״̬
	DC_Motor.Status = Stop_State;
}


//ǰ��
static void Motor_Up(void)
{
	HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_SET);
	TIM1->CCR1 = 1000;
	TIM1->CCR4 = 1000;
}
//����
static void Motor_Down(void)
{
	HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_RESET);
	TIM1->CCR1 = 1000;
	TIM1->CCR4 = 1000;
}

//��ת
static void Motor_Left(void)
{
	if(DC_Motor.Direction == Forward_State)
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_SET);
	}
	else if(DC_Motor.Direction == Reverse_State)
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_RESET);
	}
	TIM1->CCR1 = 1500;
	TIM1->CCR4 = 500;
}

//��ת
static void Motor_Right(void)
{	
	if(DC_Motor.Direction == Forward_State)
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_SET);
	}
	else if(DC_Motor.Direction == Reverse_State)
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_RESET);
	}
	
	TIM1->CCR1 = 500;
	TIM1->CCR4 = 1500;
	
}

static void Back_Car(void)
{
		DC_Motor.Motor_Down();

		if(IN3 == GPIO_PIN_RESET && IN2 == GPIO_PIN_RESET)
		{
			HAL_Delay(300);
			DC_Motor.Motor_Left();
			HAL_Delay(1000);
			HAL_Delay(500);
			DC_Motor.Motor_Down();
		}
		if(IN1 == GPIO_PIN_RESET)
			{
				HAL_Delay(300);
				DC_Motor.Stop();
				DC_Motor.Back_status = 0;
			}	
}

static void Out_Car(void)
{
		
		DC_Motor.Motor_Up();

		HAL_Delay(1000);
		DC_Motor.Motor_Left();
		HAL_Delay(1000);
		HAL_Delay(500);
		DC_Motor.Motor_Up();
		HAL_Delay(300);	
	    DC_Motor.Stop();
		DC_Motor.Back_status = 0;
}




/*
	* @name   Speed_Adjust
	* @brief  ֱ������ٶȵ���
	* @param  Speed_Change -> �ٶȱ仯
	* @retval None      
*/
static void Speed_Adjust(uint16_t Speed)
{
	if(DC_Motor.Status == Start_State)
	{
		DC_Motor.Speed = Speed;
		//����PWMռ�ձ�
		TIM1->CCR1 = DC_Motor.Speed;
		TIM1->CCR4 = DC_Motor.Speed;
	}
}
/********************************************************
  End Of File
********************************************************/
