/* Includes ------------------------------------------------------------------*/
#include "MyApplication.h"

/* Private define-------------------------------------------------------------*/

/* Private variables----------------------------------------------------------*/
static void Run(void); 
static void Error_Handler(void);
static void Assert_Failed(void);
	
/* Public variables-----------------------------------------------------------*/
System_t System = 
{
	Run,
	Error_Handler,
	Assert_Failed
};

/* Private function prototypes------------------------------------------------*/ 
uint8_t cmd = 0;
/*
	* @name   Run
	* @brief  ϵͳ����
	* @param  None
	* @retval None      
*/
static void Run()
{
	HAL_UART_Receive_IT(&huart3, &cmd, 1); 
	
	//printf("%d",cmd);
	
	if(DC_Motor.Back_status == 2)
	{
		DC_Motor.Direction = Reverse_State;
		DC_Motor.Back_Car();
	}
	else if(DC_Motor.Back_status == 3)
	{
		DC_Motor.Direction = Forward_State;
		DC_Motor.Out_Car();
	}
	
	HAL_Delay(300);
}


/*
	* @name   Error_Handler
	* @brief  ϵͳ������
	* @param  None
	* @retval None      
*/
static void Error_Handler()
{
	/* User can add his own implementation to report the HAL error return state */
}

/*
	* @name   Assert_Failed
	* @brief  ��������������
	* @param  None
	* @retval None      
*/
static void Assert_Failed()
{
	/* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	
}
/********************************************************
  End Of File
********************************************************/
