/* Includes ------------------------------------------------------------------*/
#include "MyApplication.h"

/* Private define-------------------------------------------------------------*/

/* Private variables----------------------------------------------------------*/
static void Peripheral_Set(void); 

/* Public variables-----------------------------------------------------------*/
MyInit_t MyInit = 
{
	Peripheral_Set
};

/* Private function prototypes------------------------------------------------*/      


/*
	* @name   Peripheral_Set
	* @brief  ��������
	* @param  None
	* @retval None      
*/
static void Peripheral_Set()
{
	printf("----STM32������ʵս��Ŀ - ��������1----\r\n");
	
	DC_Motor.Start();
	TIM1->CCR1 = 1000;
	TIM1->CCR4 = 1000;
	

	Timer3.Timer3_Start_IT(); //������ʱ��3
	
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_IDLE);

}

/********************************************************
  End Of File
********************************************************/
